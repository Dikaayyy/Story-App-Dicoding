package com.dicoding.story_app.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.story_app.data.repository.UserRepository
import com.dicoding.story_app.data.response.Story
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow


class StoryViewModel(
    private val userRepository: UserRepository,
    private val externalScope: CoroutineScope? = null
) : ViewModel() {
    val stories: Flow<PagingData<Story>> by lazy {
        userRepository.getAllStory().cachedIn(externalScope ?: viewModelScope)
    }
}